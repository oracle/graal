# Dummy because libraries do: require 'jruby'
