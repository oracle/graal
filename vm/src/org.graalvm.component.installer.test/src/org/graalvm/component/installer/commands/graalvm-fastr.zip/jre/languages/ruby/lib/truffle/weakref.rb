# WeakRef is available by default
