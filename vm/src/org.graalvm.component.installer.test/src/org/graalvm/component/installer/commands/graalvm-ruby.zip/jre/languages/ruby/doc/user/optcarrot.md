# Playing optcarrot

Clone the optcarrot repository.

    git clone https://github.com/mame/optcarrot.git
    cd optcarrot

You will need `mplayer` to be installed, then you can play Lan Master 
with following command.

    path/to/graalvm-0.nn/bin/ruby bin/optcarrot --video mplayer --input term examples/Lan_Master.nes

More information can be found in Benoit's [blog post](https://eregon.me/blog/2016/11/28/optcarrot.html).
