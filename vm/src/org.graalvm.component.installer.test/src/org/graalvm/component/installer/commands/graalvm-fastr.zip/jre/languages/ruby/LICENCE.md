# TruffleRuby Licence

TruffleRuby is copyright (c) 2013-2017 Oracle and/or its
affiliates, and is made available to you under the terms of three licenses:

* Eclipse Public License version 1.0
* GNU General Public License version 2
* GNU Lesser General Public License version 2.1

TruffleRuby contains additional code not always covered by these licences, and
with copyright owned by other people. See
[doc/legal/legal.md](doc/legal/legal.md) for full documentation.
