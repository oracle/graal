# Using Docker

Oracle publishes a `Dockerfile` for GraalVM.

https://github.com/oracle/docker-images/tree/master/GraalVM

The version of GraalVM in that repository may be out of date, so check what is
available [on OTN at the time](using-graalvm.md).
